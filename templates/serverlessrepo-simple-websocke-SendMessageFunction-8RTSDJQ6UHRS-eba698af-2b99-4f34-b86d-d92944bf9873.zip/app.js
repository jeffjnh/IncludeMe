// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

const AWS = require('aws-sdk');
AWS.config.update({ region: process.env.AWS_REGION });
const ddb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
var DDB = new AWS.DynamoDB({ apiVersion: "2012-10-08" });

const { TABLE_NAME } = process.env;


/**
 * 
 * 
 * Lambda Function Handler
 * 
 */
exports.handler = async (event, context, callback) => {
  let connectionData;
  console.log(event);
  var input = JSON.parse(event.body);
  var cid_from_input = input["chime_pin"];
  console.log(input);
  
  console.log(input["data"]);
  if (input["data"] === "includeMe" ||
  input["data"] === "unIncludeMe" ||
  input["data"] === "anonIncl" ||
  input['data'] === "makeAnon"
) {
	var putParams = {
		TableName: process.env.TABLE_NAME,
		Item: {
		  connectionId: { S: event.requestContext.connectionId },
		  email:{ S: input["email"] },
		  chime_pin: { S: input["chime_pin"] },
		  anonymous: { S: input["anonymous"].toString() },
		  included: { S: input["data"] === "includeMe" ? "true" : "false" },
		  anonIncl: { S: input["data"] === "anonIncl" ? "true" : "false" },
		  tstamp: { S: input["data"] === "includeMe" ?  input["time"].toString() : "0" }
		}
	  };
	  console.log(putParams);
	
	await DDB.putItem(putParams, function (err) {
		// console.log(err);
		callback(null, {
		  statusCode: err ? 500 : 200,
		  body: err ? "Failed to connect: " + JSON.stringify(err) : "Connected."
		});
	  }).promise();
	}
  
  
  // console.log(cid_from_input);
  try {
    connectionData = await ddb.query({ TableName: TABLE_NAME,
    ProjectionExpression: 'chime_pin, email, connectionId, included, anonymous, anonIncl, tstamp',
    KeyConditionExpression: "#cid = :id_in",
    ExpressionAttributeNames: {
      "#cid": "chime_pin"
    },
    ExpressionAttributeValues: {
      ":id_in": cid_from_input
    } }).promise();
  } catch (e) {
    console.log(e);
    console.log("Connection data: ");
      console.log(connectionData);
    return { statusCode: 500, body: e.stack };
  }
 
  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: '2018-11-29',
    endpoint: event.requestContext.domainName + '/' + event.requestContext.stage
  });
  
 /**
  * 
  * Generate postData, an object to forward Call Status information with all the users
  * back to the call observers
  * 
  */
  const postData= JSON.stringify({users: connectionData.Items});
  // console.log("Post Data: ");
  // console.log(postData);
  
  const postCalls = connectionData.Items.map(async ({ connectionId }) => {
    try {
      await apigwManagementApi.postToConnection({ ConnectionId: connectionId, Data: postData }).promise();
    } catch (e) {
      if (e.statusCode === 410) {
        console.log(`Found stale connection, deleting ${connectionId}`);
  //       let connectionData;
  // // need to get the key and name using the id:
  // // try {
  //   connectionData = await DDB.query({ TableName: TABLE_NAME,
  //   IndexName: 'connectionId-index',
  //   ProjectionExpression: 'chime_pin, email, connectionId',
  //   KeyConditionExpression: "#idx = :id_in",
  //   ExpressionAttributeNames: {
  //     "#idx": "connectionId"
  //   },
  //   ExpressionAttributeValues: {
  //     ":id_in": { S: connectionId}
  //   } }).promise();


  // var cPin = connectionData.Items[0].chime_pin.S;
  // var email = connectionData.Items[0].email.S;

  // // console.log(cPin);
  // // console.log(email);
  // var deleteParams = {
  //   TableName: process.env.TABLE_NAME,
  //   Key: {
  //     "chime_pin": { S: cPin.toString() },
  //     "email": { S: email.toString() }
  //   }
  // };

  // await DDB.deleteItem(deleteParams, function (err) {
  //   callback(null, {
  //     statusCode: err ? 500 : 200,
  //     body: err ? "Failed to disconnect: " + JSON.stringify(err) : "Disconnected."
  //   });
  // }).promise();
        // await ddb.delete({ TableName: TABLE_NAME, Key: { connectionId } }).promise();
      } else {
        // console.log(e);
        throw e;
      }
    }
  });
  
  try {
    await Promise.all(postCalls);
  } catch (e) {
    return { statusCode: 500, body: e.stack };
  }

  return { statusCode: 200, body: 'Data sent.' };
};
