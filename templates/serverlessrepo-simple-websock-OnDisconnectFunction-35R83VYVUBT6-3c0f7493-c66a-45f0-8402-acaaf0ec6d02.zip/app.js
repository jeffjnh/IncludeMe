


// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

var AWS = require("aws-sdk");
AWS.config.update({ region: process.env.AWS_REGION });
var DDB = new AWS.DynamoDB({ apiVersion: "2012-10-08" });
const ddb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
const { TABLE_NAME } = process.env;

exports.handler = async function (event, context, callback) {
let connectionData;
  // need to get the key and name using the id:
  // try {
    connectionData = await DDB.query({ TableName: TABLE_NAME,
    IndexName: 'connectionId-index',
    ProjectionExpression: 'chime_pin, email, connectionId',
    KeyConditionExpression: "#idx = :id_in",
    ExpressionAttributeNames: {
      "#idx": "connectionId"
    },
    ExpressionAttributeValues: {
      ":id_in": { S: event.requestContext.connectionId}
    } }).promise();
  // } catch (e) {

  //   return { statusCode: 500, body: e.stack };
  // }



  var cPin = connectionData.Items[0].chime_pin.S;
  var email = connectionData.Items[0].email.S;

  // console.log(cPin);
  // console.log(email);
  var deleteParams = {
    TableName: process.env.TABLE_NAME,
    Key: {
      "chime_pin": { S: cPin.toString() },
      "email": { S: email.toString() }
    }
  };

  await DDB.deleteItem(deleteParams, function (err) {
    callback(null, {
      statusCode: err ? 500 : 200,
      body: err ? "Failed to disconnect: " + JSON.stringify(err) : "Disconnected."
    });
  }).promise();
  
   try {
    connectionData = await ddb.query({ TableName: TABLE_NAME,
    ProjectionExpression: 'chime_pin, email, connectionId, included, anonymous, anonIncl, tstamp',
    KeyConditionExpression: "#cid = :id_in",
    ExpressionAttributeNames: {
      "#cid": "chime_pin"
    },
    ExpressionAttributeValues: {
      ":id_in": cPin.toString()
    } }).promise();
  } catch (e) {
    // console.log(e);
    // console.log("Connection data: ");
      // console.log(connectionData);
    return { statusCode: 500, body: e.stack };
  }
 
  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: '2018-11-29',
    endpoint: event.requestContext.domainName + '/' + event.requestContext.stage
  });
  
 /**
  * 
  * Generate postData, an object to forward Call Status information with all the users
  * back to the call observers
  * 
  */
  const postData= JSON.stringify({users: connectionData.Items});
  
  // console.log(postData);
  
  const postCalls = connectionData.Items.map(async ({ connectionId }) => {
    try {
      await apigwManagementApi.postToConnection({ ConnectionId: connectionId, Data: postData }).promise();
    } catch (e) {
      if (e.statusCode === 410) {
        console.log(`Found stale connection, deleting ${connectionId}`);
        await DDB.delete({ TableName: TABLE_NAME, Key: { connectionId } }).promise();
      } else {
        // console.log(e);
        throw e;
      }
    }
  });
  
  try {
    await Promise.all(postCalls);
  } catch (e) {
    return { statusCode: 500, body: e.stack };
  }

  return { statusCode: 200, body: 'Data sent.' };


};
