// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

var AWS = require("aws-sdk");
AWS.config.update({ region: process.env.AWS_REGION });
const ddb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
var DDB = new AWS.DynamoDB({ apiVersion: "2012-10-08" });
const { TABLE_NAME } = process.env;

exports.handler = async function (event, context, callback) {
  console.log(event);
  let connectionData;
  var putParams = {
    TableName: process.env.TABLE_NAME,
    Item: {
      connectionId: { S: event.requestContext.connectionId },
      email:{ S: event.queryStringParameters.email },
      chime_pin: { S: event.queryStringParameters.chime_pin },
      anonymous:{ S: event.queryStringParameters.anonymous },
      anonIncl:{ S: "false" },
      tstamp:{ S: "0" },
      included: { S: "false" },
      
    }
  };

  await DDB.putItem(putParams, function (err) {
    // console.log(err);
    callback(null, {
      statusCode: err ? 500 : 200,
      body: err ? "Failed to connect: " + JSON.stringify(err) : "Connected."
    });
    console.log(err);
  }).promise();
//   try {
//     connectionData = await ddb.query({ TableName: TABLE_NAME,
//     ProjectionExpression: 'chime_pin, email, connectionId, included, anonymous, tstamp',
//     KeyConditionExpression: "#cid = :id_in",
//     ExpressionAttributeNames: {
//       "#cid": "chime_pin"
//     },
//     ExpressionAttributeValues: {
//       ":id_in": event.queryStringParameters.chime_pin
//     } }).promise();
//   } catch (e) {
//     console.log(e);
//     // console.log("Connection data: ");
//       // console.log(connectionData);
//     return { statusCode: 500, body: e.stack };
//   }
 
//   const apigwManagementApi = new AWS.ApiGatewayManagementApi({
//     apiVersion: '2018-11-29',
//     endpoint: event.requestContext.domainName + '/' + event.requestContext.stage
//   });
  
// /**
//   * 
//   * Generate postData, an object to forward Call Status information with all the users
//   * back to the call observers
//   * 
//   */
//   const postData= JSON.stringify({users: connectionData.Items});
  
//   console.log(postData);
  
//   const postCalls = connectionData.Items.map(async ({ connectionId }) => {
//     console.log(connectionId);
//     try {
//       await apigwManagementApi.postToConnection({ ConnectionId: connectionId, Data: postData }).promise();
//     } catch (e) {
//       console.log(e);
//       // if (e.statusCode === 410) {
//       //   console.log(`Found stale connection, deleting ${connectionId}`);
//       //   await DDB.delete({ TableName: TABLE_NAME, Key: { connectionId } }).promise();
//       // } else {
//       //   // console.log(e);
//         // throw e;
//       // }
//     }
//   });
  
//   try {
//     await Promise.all(postCalls);
//   } catch (e) {
//     console.log(e);
//     return { statusCode: 500, body: e.stack };
//   }

//   return { statusCode: 200, body: 'Data sent.' };


};
